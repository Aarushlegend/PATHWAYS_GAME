var bg, bgImage;
var player, playerImage;
var ground;
var leftWall, reightWall;
var ground;
var bulletGroup;
var bulletImage;
var bulletSound;
var bulletCock;
var walking;
var germ1, germ1Image;
var germsGroup;
var b = 35;
var flag = 0;
let sprWalker;
var score;
var secondSprite, secondSpriteImage;
var dettolHandwash, dettolHandwashImage;
var dettolSanitizer, dettolSanitizerImage;
var dettolSoap, dettolSoapImage, explode_sprite_sheet;
var germ, germImage;
var walking;
var GRAVITY = 0.3;
var x1 = 0;
var x2;
var score = 0;
var count = 0;
var isGrounded = false;
var powerUps = 'Normal';
var canShoot = true;
var powerup1;
var powerup2;
var powerup3;
var bulletCount;
var health = 100;
var gamestate = "play";
var gameOver;
var restart;




// var astroid_frames= [];
//   for (var j = 0; j < 9; j++) {
//     for (var t = 0; t < 9; t++) {
//     astroid_frames.push({"name":"player_walk0"+((j+1)*(t+1)), "frame":{"x":128*t, "y": 128*j, 	"width": 128, "height": 128}});
//     }
//   }

function preload() {
    bgImage = loadImage('./background.jpg')
    playerImage = loadImage("./gun sprite.png")
    bulletImage = loadImage("./bullet.png")
    bulletSound = loadSound("./shot.mp3")
    bulletCock = loadSound("./gunCock.mp3")
    walking = loadSound("./walking.mp3")
    germ1Image = loadImage("./germ1.png")
    secondSpriteImage = loadImage("./secondSprite.png")
    dettolHandwash = loadImage("./dettolhandwash.png")
    dettolSanitizer = loadImage("./dettolsanitizer.png")
    dettol1 = loadImage("./dettolSoap.png")
    explode_sprite_sheet = loadSpriteSheet('./explosion1024_768.png', 128, 128, 48);
    player_sprite_sheet = loadSpriteSheet('./player.png', 59, 66, 10);
    gameOverImage = loadImage("Game_oversprite.png")
}

function setup() {
    createCanvas(windowWidth, windowHeight);
    x2 = width;
    player = createSprite(80, 480, 59, 66);
    player.scale=2;
    player.addAnimation('running', player_sprite_sheet);
    player.animation.frameDelay = 7;
    player.animation.looping = true;
    // player.addImage(playerImage);

    ground = createSprite(windowWidth / 2, windowHeight * .82, windowWidth, 10);
    leftWall = createSprite(-50, windowHeight / 2, 10, windowHeight);
    rightWall = createSprite(windowWidth + 50, windowHeight / 2, 10, windowHeight);
    gameOver = createSprite(windowWidth / 2, windowHeight / 3)
    gameOver.addImage(gameOverImage)
    ground.visible = false;

    bulletGroup = new Group();
    germsGroup = new Group();

    powerup1 = createSprite(windowWidth - 270, 850, 30, 30);
    powerup2 = createSprite(windowWidth - 200, 850, 30, 30);
    powerup3 = createSprite(windowWidth - 130, 850, 30, 30);
    bulletCount = 35;
    gameOver.visible = false;

}
function BackgroundMovement() {
    image(bgImage, x1, 0, width, windowHeight);
    image(bgImage, x2, 0, width, windowHeight);
    x1 -= 1;
    x2 -= 1;

    if (x1 < -width) {
        x1 = width;
    }
    if (x2 < -width) {
        x2 = width;
    }
}
function PlayerControls() {
    if (keyWentDown("CTRL") && canShoot && bulletCount > 0) {
        spawnBullets();
        canShoot = false;
        setTimeout(() => { canShoot = true; }, 150);
        bulletCount = bulletCount - 1;
    }

    if ((keyDown(UP_ARROW) || keyWentDown("w") || keyWentDown("space")) && isGrounded) {
        player.velocity.y = -12;
    }
}
function ApplyGravity() {
    player.velocity.y += GRAVITY;
    if (ground.overlap(player)) {
        player.velocity.y = 0;
        isGrounded = true;
    } else {
        isGrounded = false;
    }
}


function GameOverConditions() {
}

function HealthController() {
    germsGroup.overlap(player, (a, b) => {
        a.remove();
        health = health - 25;
        if (health == 0) {
            player.remove();
            gamestate = "end";
        }
    })
}

function draw() {
    console.log(gamestate)
    switch (gamestate) {
        case 'play':
            BackgroundMovement();
            ApplyGravity()
            PlayerControls();
            HealthController();
            GameOverConditions();
            germsGroup.overlap(leftWall, (a, b) => {
                a.remove();
            })
            bulletGroup.overlap(rightWall, (a, b) => {
                a.remove();
            })

            bulletGroup.overlap(germsGroup, (a, b) => {
                a.remove();
                b.remove();
                sprWalker = createSprite(b.position.x, b.position.y, 60, 60);
                sprWalker.scale = .4;
                sprWalker.addAnimation('explode', explode_sprite_sheet);
                sprWalker.scale = .4;
                sprWalker.animation.frameDelay = 1;
                sprWalker.animation.looping = false;
                score++;
            });
            if (score < 10) {
                spawnGerms();
            }

            textSize(25);
            fill(0)
            text(" Score  " + score, windowWidth - 207, 80)
            text("Bullets Left  " + bulletCount, windowWidth - 200, 50);
            text("Health  " + health, windowWidth - 200, 110)
            break;
        case "end":
            gameOver.visible = true;
            console.log(typeof(germsGroup));
            for (i = 0; i<germsGroup.length;i++){
                var removableGerm = germsGroup.get(0);
                removableGerm.remove();
            }
            for (i = 0; i<bulletGroup.length;i++){
                var removableBullets = bulletGroup.get(0);
                removableBullets.remove();
            }
            break;
    }
    drawSprites();


}

function spawnBullets() {
    switch (powerUps) {
        case 'Normal':
            var bullet = createSprite(player.position.x + 60, player.position.y - 33);
            bullet.addImage(bulletImage);
            bulletSound.play();
            bullet.setSpeed(5);
            bullet.lifetime = 20;
            bullet.scale = 0.2;
            bulletGroup.add(bullet);
            break;
        case 'BurstShot':
            var bullet = createSprite(player.position.x + 60, player.position.y - 33);
            bullet.addImage(bulletImage);
            bulletSound.play();
            bullet.setSpeed(5);
            bullet.lifetime = 20;
            bullet.scale = 0.2;
            bulletGroup.add(bullet);

            bullet = createSprite(player.position.x + 60, player.position.y - 33);
            bullet.addImage(bulletImage);
            bulletSound.play();
            bullet.setSpeed(5,30);
            bullet.lifetime = 20;
            bullet.scale = 0.2;
            bulletGroup.add(bullet);

            bullet = createSprite(player.position.x + 60, player.position.y - 33);
            bullet.addImage(bulletImage);
            bulletSound.play();
            bullet.setSpeed(5,-30);
            bullet.lifetime = 20;
            bullet.scale = 0.2;
            bulletGroup.add(bullet);

            bullet = createSprite(player.position.x + 60, player.position.y - 33);
            bullet.addImage(bulletImage);
            bulletSound.play();
            bullet.setSpeed(5,15);
            bullet.lifetime = 20;
            bullet.scale = 0.2;
            bulletGroup.add(bullet);

            bullet = createSprite(player.position.x + 60, player.position.y - 33);
            bullet.addImage(bulletImage);
            bulletSound.play();
            bullet.setSpeed(5,-15);
            bullet.lifetime = 20;
            bullet.scale = 0.2;
            bulletGroup.add(bullet);
           
            break;
    }
}

function spawnGerms() {
    if (frameCount % 100 === 0) {
        var germ = createSprite(windowWidth, windowHeight * .7);
        germ.addImage(germ1Image);
        germ.position.y = Math.round(random(windowHeight * .7, windowHeight * .5));
        germ.setSpeed(-5);
        germ.lifetime = 100;
        germ.scale = 0.35;
        germsGroup.add(germ);
    }
}